function recojerDatos(){

    let nombre = document.getElementById("nombre").value;
    let apellido1 = document.getElementById("apellido1").value;
    let apellido2 = document.getElementById("apellido2").value;
}


let mensaje = "El usuario con nombre : "  + nombre  + "" + apellido1 + "" + apellido2;

prompt(mensaje);